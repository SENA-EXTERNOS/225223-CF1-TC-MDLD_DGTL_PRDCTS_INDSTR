function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6VdLT7anTZJ":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

